package com.example.newproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class SignupActivity extends AppCompatActivity {

    public EditText emailU, usernameU;
    public TextInputEditText passwordU, confirmpassU;
    public Button signupButtonU;
    public TextView signupU;
    String message;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAuth = FirebaseAuth.getInstance();
        setContentView(R.layout.activity_signup);

        emailU = findViewById(R.id.emailSignUp);
        usernameU = findViewById(R.id.usernameSignUp);
        passwordU = findViewById(R.id.passwordSignUp);
        confirmpassU = findViewById(R.id.confirmpasswordSignUp);

        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();

        signupButtonU = findViewById(R.id.signupButtonSignUp);
        signupU = findViewById(R.id.signinText);

        signupButtonU.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                if (isConnected) {
                    if (validateUserDetails()) {
                        registerUser(emailU.getText().toString(), passwordU.getText().toString());
                    }
                }
                else
                {
                    showToast("No Internet Connection, Please Connect your Device.");
                }
            }
        });

        signupU.setOnClickListener(new View.OnClickListener()  {
            @Override
            public void onClick(View v)  {
                Intent intent = new Intent(SignupActivity.this, SinginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    public void registerUser(String email, String password){
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("LOGS", "createUserWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            if(user != null) {
                                Log.d("USER", user.toString());
                                user.sendEmailVerification()
                                        .addOnCompleteListener(task1 -> {
                                            if (task1.isSuccessful()) {
                                                Log.d("USER_LOG_EMAIL", "Email sent.");
                                                showToast("Sign Up Successful. \nVerification is send to your Email.\nMoving to Log In Page");
                                                Handler handler = new Handler();
                                                handler.postDelayed(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        Intent intent = new Intent(SignupActivity.this, SinginActivity.class);
                                                        startActivity(intent);
                                                    }
                                                }, 2000);
                                                FirebaseFirestore db = FirebaseFirestore.getInstance();

                                                Map<String, Object> userObj = new HashMap<>();
                                                userObj.put(Constants.KEY_USER_ID, user.getUid());
                                                userObj.put(Constants.KEY_USER_FIRST_NAME, null);
                                                userObj.put(Constants.KEY_USER_LAST_NAME, null);
                                                userObj.put(Constants.KEY_USER_MIDDLE_INITIAL, null);
                                                userObj.put(Constants.KEY_USER_EMAIL, emailU.getText().toString());
                                                userObj.put(Constants.KEY_USER_BIRTH_DATE, null);
                                                userObj.put(Constants.KEY_USER_ADDRESS, null);
                                                userObj.put(Constants.KEY_USER_PROFILE_PIC, null);

                                                db.collection(Constants.KEY_COLLECTION_PROFILE)
                                                        .document(user.getUid())
                                                        .set(userObj)
                                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                            @Override
                                                            public void onSuccess(Void aVoid) {
                                                                Log.d("SAVE_USER_DATA", "DocumentSnapshot successfully written!");
                                                            }
                                                        })
                                                        .addOnFailureListener(new OnFailureListener() {
                                                            @Override
                                                            public void onFailure(@NonNull Exception e) {
                                                                Log.w("SAVE_USER_DATA", "Error writing document", e);
                                                            }
                                                        });
                                            }
                                        });
                            }
//                            updateUI(user);
                        }
                        else {
                            // If sign in fails, display a message to the user.
                            Log.w("LOGS", "createUserWithEmail:failure", task.getException());
                            showToast("Authentication failed.");
//                            updateUI(null);
                        }
                    }
                });
    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
//            reload();
            Log.d("NO_USER", "No user Log in");
        }
    }

    private void showToast(String message) {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }

    public Boolean validateUserDetails() {
        if (emailU.getText().toString().isEmpty()) {
            showToast("Enter Email please.");
            return false;

        } else if (usernameU.getText().toString().isEmpty()) {
            showToast("Enter Username please.");
            return false;

        } else if (passwordU.getText().toString().isEmpty()) {
            showToast("Enter Password please.");
            return false;
        } else if (passwordU.getText().toString().length() <= 5) {
            showToast("Password must have 6 characters.");
            return false;

        } else if (confirmpassU.getText().toString().isEmpty()) {
            showToast("Enter Confirm Password please.");
            return false;

        } else if (!passwordU.getText().toString().equals(confirmpassU.getText().toString())) {
            showToast("Password and Confirm Password not Match.");
            return false;

        } else {
            return true;
        }
    }
}