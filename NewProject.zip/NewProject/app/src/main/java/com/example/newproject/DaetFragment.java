package com.example.newproject;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class DaetFragment extends Fragment {

    public Button mVisitDaetPineApple;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_daet, container, false);

        mVisitDaetPineApple = view.findViewById(R.id.daet_pineapple_resort);
        mVisitDaetPineApple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToVisit();
            }
        });
        // Inflate the layout for this fragment
        return view;
    }

    public void goToVisit() {
        Intent intent = new Intent(getActivity(), PineAppleDaetActivity.class);
        startActivity(intent);
    }
}