package com.example.newproject;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import java.util.Calendar;

public class ProfileFragment extends Fragment {

    private static final int REQUEST_PERMISSION = 1;
    private static final int REQUEST_IMAGE = 2;
    public Button mUpdateProfile;

    public EditText mBirthdate;
    public ImageView mProfilePic, mBirthdatePic;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        mUpdateProfile = view.findViewById(R.id.update_profile_pic);
        mProfilePic = view.findViewById(R.id.profile_pic);
        mBirthdate = view.findViewById(R.id.birthdateProfile);
        mBirthdatePic = view.findViewById(R.id.birthdateProfile_pic);

        mUpdateProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(getActivity(),
                        android.Manifest.permission.READ_EXTERNAL_STORAGE) ==
                        PackageManager.PERMISSION_GRANTED) {
                    selectImage();
                }
                else {
                    ActivityCompat.requestPermissions(getActivity(),
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                            REQUEST_PERMISSION);
                }
            }
        });

        return view;
    }

    private void selectImage() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, REQUEST_IMAGE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                selectImage();
            } else {
                Toast.makeText(getActivity(), "Permission denied. Cannot select image.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE && resultCode == Activity.RESULT_OK) {
            if (data != null) {
                Uri selectedImageUri = data.getData();
                if (selectedImageUri != null) {
                    try {
                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), selectedImageUri);
                        mProfilePic.setImageBitmap(bitmap);
                        // You can now upload the image to a server or perform other actions with it.
                    } catch (Exception e) {
                        Log.e("ImageUpload", "Error loading image: " + e.getMessage());
                    }
                }
            }
        }
    }

//    @Override
//    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
//        Calendar cal = Calendar.getInstance();
//        cal.set(Calendar.YEAR, year);
//        cal.set(Calendar.MONTH, month);
//        cal.set(Calendar.DAY_OF_MONTH, dayOfMonth);
//
//        String year_string = Integer.toString(year);
//        String month_string = Integer.toString(month + 1);
//        String day_string = Integer.toString(dayOfMonth);
//
//        String date_message = ("BirthDate: "+ month_string + "/" + day_string +"/"+ year_string);
////        String currentDateString = DateFormat.getDateInstance(DateFormat.FULL).format(cal.getTime());
//
//        if (mBirthdate.getText().toString().equals(null)) {
//
//        } else {
//            mBirthdate.setText(date_message);
//        }
////        Toast.makeText(this, date_message, Toast.LENGTH_SHORT).show();
//    }
}