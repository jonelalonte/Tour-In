package com.example.newproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class SinginActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private PreferenceUserManager userManager;
    FirebaseFirestore db;
    EditText emailI;
    EditText passwordI;
    Button loginButtonI;
    TextView signupButtonI;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        mAuth = FirebaseAuth.getInstance();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_singin);

        db = FirebaseFirestore.getInstance();
        userManager = new PreferenceUserManager(getApplicationContext());

        emailI = findViewById(R.id.emailSignIn);
        passwordI = findViewById(R.id.passwordSigIn);
        loginButtonI = findViewById(R.id.loginButtonSingIn);
        signupButtonI = findViewById(R.id.signupText);

        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();

        loginButtonI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Toast.makeText(MainActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();
//                Intent intent = new Intent(MainActivity.this, HomeActivity.class);
//                startActivity(intent);
//                emailI.setText("");
//                passwordI.setText("");

                if(isConnected){
                    if (validateUserDetails()){
                        signInUser(emailI.getText().toString(), passwordI.getText().toString());
                    }
                    else {
                        showToast("User not Found, Please register to proceed.");
                    }
                }
                else {
                    showToast("No Internet Connection, Please connect your Device.");
                }
            }
        });

        signupButtonI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SinginActivity.this, SignupActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
//        Log.d("currentUser", String.valueOf(currentUser.isEmailVerified()));
//        Log.d("currentUser", currentUser.getEmail());
        if(currentUser != null && currentUser.isEmailVerified()){
            DocumentReference docRef = db.collection(Constants.KEY_COLLECTION_PROFILE).document(currentUser.getUid());
            docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();
                        if (document.exists()) {
                            Log.d("currentUser", "DocumentSnapshot data: " + document.getData());
                            userManager.putString(Constants.KEY_USER_EMAIL, currentUser.getEmail());
                            userManager.putString(Constants.KEY_USER_ID, currentUser.getUid());
                            userManager.putString(Constants.KEY_USER_ADDRESS, document.getString(Constants.KEY_USER_ADDRESS));
                            userManager.putString(Constants.KEY_USER_BIRTH_DATE, document.getString(Constants.KEY_USER_BIRTH_DATE));
                            userManager.putString(Constants.KEY_USER_FIRST_NAME, document.getString(Constants.KEY_USER_FIRST_NAME));
                            userManager.putString(Constants.KEY_USER_MIDDLE_INITIAL, document.getString(Constants.KEY_USER_MIDDLE_INITIAL));
                            userManager.putString(Constants.KEY_USER_LAST_NAME, document.getString(Constants.KEY_USER_LAST_NAME));
                            userManager.putString(Constants.KEY_USER_PROFILE_PIC, document.getString(Constants.KEY_USER_PROFILE_PIC));

                            Log.d("currentUserEmail", userManager.getString(Constants.KEY_USER_EMAIL));
                        } else {
                            Log.d("currentUser", "No such document");
                            showToast("No Record Found.");
                        }
                    } else {
                        Log.d("currentUser", "get failed with ", task.getException());
                    }
                }
            });
        }
        else {
            Log.d("currentUser", "get failed with email and pass");
        }
    }

    public void signInUser(String email, String password){
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("CHECK_USER", "signInWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();

                            if (user != null && user.isEmailVerified()) {
                                Toast.makeText(SinginActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        Intent intent = new Intent(SinginActivity.this, HomeActivity.class);
                                        startActivity(intent);
                                        emailI.setText("");
                                        passwordI.setText("");
                                    }
                                }, 1000);
                            } else {
                                Toast.makeText(SinginActivity.this, "Account is not verified! Please check your email.", Toast.LENGTH_SHORT).show();
                            }

//                            updateUI(user);
                        } else {
                            // If sign in fails, display a message to the user.
                            Log.d("CHECK_USER", "signInWithEmail:failure", task.getException());
                            showToast("Password don't Match OR Email don't exists.");
                        }
                    }
                });
    }

    private void showToast(String message) {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }

    public Boolean validateUserDetails() {
        if (emailI.getText().toString().isEmpty()) {
            showToast("Enter Email please");
            return false;
        } else if (passwordI.getText().toString().isEmpty()) {
            showToast("Enter Password please.");
            return false;
        } else {
            return true;
        }
    }

}