package com.example.newproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class PineAppleDaetActivity extends AppCompatActivity {

    public ImageView mBackIconButton;
    public TextView mSeeMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pine_apple_daet);

        mBackIconButton = findViewById(R.id.back_icon_button);
        mSeeMap = findViewById(R.id.see_map_pineapple);

        mBackIconButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PineAppleDaetActivity.this, HomeActivity.class);
                startActivity(intent);
            }
        });

        mSeeMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String loc = "Pineapple Island Resort Camarines Norte, San Lorenzo Ruiz Road, Daet, Camarines Norte";
                Uri addressUri = Uri.parse("geo:0,0?q=" + loc);
                Intent intent = new Intent(Intent.ACTION_VIEW, addressUri);

                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                } else {
                    Log.d("ImplicitIntents", "Can't handle this intent.");
                }
            }
        });

    }
}