package com.example.newproject;

public class Constants {
    public static final String KEY_PREFERENCE_NAME = "user_manager";

    // USER KEY
    public static final String KEY_USER_ID = "id";
    public static final String KEY_USER_EMAIL = "email";
    public static final String KEY_USER_FIRST_NAME = "first_name";
    public static final String KEY_USER_LAST_NAME = "last_name";
    public static final String KEY_USER_MIDDLE_INITIAL = "middle_initial";
    public static final String KEY_USER_ADDRESS = "address";
    public static final String KEY_USER_BIRTH_DATE = "birth_date";
    public static final String KEY_USER_PROFILE_PIC = "profile_pic";

    // Collection key
    public static final String KEY_COLLECTION_PROFILE = "profiles";

}
